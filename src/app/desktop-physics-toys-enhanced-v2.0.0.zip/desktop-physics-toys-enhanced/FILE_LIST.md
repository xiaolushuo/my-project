# 📁 文件清单

## 项目结构
```
[
  {
    "type": "directory",
    "name": "assets",
    "path": "assets",
    "children": [
      {
        "type": "file",
        "name": "basketball.png",
        "path": "assets/basketball.png",
        "size": 5769,
        "modified": "2025-09-01T03:52:56.933Z"
      },
      {
        "type": "file",
        "name": "basketball.png.import",
        "path": "assets/basketball.png.import",
        "size": 771,
        "modified": "2025-09-01T03:52:56.933Z"
      },
      {
        "type": "file",
        "name": "paper_plane.png",
        "path": "assets/paper_plane.png",
        "size": 215,
        "modified": "2025-09-01T03:52:56.933Z"
      },
      {
        "type": "file",
        "name": "paper_plane.png.import",
        "path": "assets/paper_plane.png.import",
        "size": 774,
        "modified": "2025-09-01T03:52:56.933Z"
      },
      {
        "type": "file",
        "name": "篮球.png",
        "path": "assets/篮球.png",
        "size": 919620,
        "modified": "2025-09-01T03:52:56.933Z"
      },
      {
        "type": "file",
        "name": "篮球.png.import",
        "path": "assets/篮球.png.import",
        "size": 759,
        "modified": "2025-09-01T03:52:56.933Z"
      }
    ]
  },
  {
    "type": "directory",
    "name": "paper_airplane_frames",
    "path": "paper_airplane_frames",
    "children": [
      {
        "type": "file",
        "name": "paper_airplane_000.png",
        "path": "paper_airplane_frames/paper_airplane_000.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_000.png.import",
        "path": "paper_airplane_frames/paper_airplane_000.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_001.png",
        "path": "paper_airplane_frames/paper_airplane_001.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_001.png.import",
        "path": "paper_airplane_frames/paper_airplane_001.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_002.png",
        "path": "paper_airplane_frames/paper_airplane_002.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_002.png.import",
        "path": "paper_airplane_frames/paper_airplane_002.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_003.png",
        "path": "paper_airplane_frames/paper_airplane_003.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_003.png.import",
        "path": "paper_airplane_frames/paper_airplane_003.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_004.png",
        "path": "paper_airplane_frames/paper_airplane_004.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_004.png.import",
        "path": "paper_airplane_frames/paper_airplane_004.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_005.png",
        "path": "paper_airplane_frames/paper_airplane_005.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_005.png.import",
        "path": "paper_airplane_frames/paper_airplane_005.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_006.png",
        "path": "paper_airplane_frames/paper_airplane_006.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_006.png.import",
        "path": "paper_airplane_frames/paper_airplane_006.png.import",
        "size": 809,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_007.png",
        "path": "paper_airplane_frames/paper_airplane_007.png",
        "size": 118,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_007.png.import",
        "path": "paper_airplane_frames/paper_airplane_007.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_008.png",
        "path": "paper_airplane_frames/paper_airplane_008.png",
        "size": 189,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_008.png.import",
        "path": "paper_airplane_frames/paper_airplane_008.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_009.png",
        "path": "paper_airplane_frames/paper_airplane_009.png",
        "size": 232,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_009.png.import",
        "path": "paper_airplane_frames/paper_airplane_009.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_010.png",
        "path": "paper_airplane_frames/paper_airplane_010.png",
        "size": 231,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_010.png.import",
        "path": "paper_airplane_frames/paper_airplane_010.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_011.png",
        "path": "paper_airplane_frames/paper_airplane_011.png",
        "size": 227,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_011.png.import",
        "path": "paper_airplane_frames/paper_airplane_011.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_012.png",
        "path": "paper_airplane_frames/paper_airplane_012.png",
        "size": 219,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_012.png.import",
        "path": "paper_airplane_frames/paper_airplane_012.png.import",
        "size": 809,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_013.png",
        "path": "paper_airplane_frames/paper_airplane_013.png",
        "size": 237,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_013.png.import",
        "path": "paper_airplane_frames/paper_airplane_013.png.import",
        "size": 809,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_014.png",
        "path": "paper_airplane_frames/paper_airplane_014.png",
        "size": 229,
        "modified": "2025-09-01T03:52:56.934Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_014.png.import",
        "path": "paper_airplane_frames/paper_airplane_014.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_015.png",
        "path": "paper_airplane_frames/paper_airplane_015.png",
        "size": 182,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_015.png.import",
        "path": "paper_airplane_frames/paper_airplane_015.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_016.png",
        "path": "paper_airplane_frames/paper_airplane_016.png",
        "size": 252,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_016.png.import",
        "path": "paper_airplane_frames/paper_airplane_016.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_017.png",
        "path": "paper_airplane_frames/paper_airplane_017.png",
        "size": 253,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_017.png.import",
        "path": "paper_airplane_frames/paper_airplane_017.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_018.png",
        "path": "paper_airplane_frames/paper_airplane_018.png",
        "size": 233,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_018.png.import",
        "path": "paper_airplane_frames/paper_airplane_018.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_019.png",
        "path": "paper_airplane_frames/paper_airplane_019.png",
        "size": 235,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_019.png.import",
        "path": "paper_airplane_frames/paper_airplane_019.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_020.png",
        "path": "paper_airplane_frames/paper_airplane_020.png",
        "size": 222,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_020.png.import",
        "path": "paper_airplane_frames/paper_airplane_020.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_021.png",
        "path": "paper_airplane_frames/paper_airplane_021.png",
        "size": 231,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_021.png.import",
        "path": "paper_airplane_frames/paper_airplane_021.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_022.png",
        "path": "paper_airplane_frames/paper_airplane_022.png",
        "size": 201,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_022.png.import",
        "path": "paper_airplane_frames/paper_airplane_022.png.import",
        "size": 809,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_023.png",
        "path": "paper_airplane_frames/paper_airplane_023.png",
        "size": 122,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_023.png.import",
        "path": "paper_airplane_frames/paper_airplane_023.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_024.png",
        "path": "paper_airplane_frames/paper_airplane_024.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_024.png.import",
        "path": "paper_airplane_frames/paper_airplane_024.png.import",
        "size": 809,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_025.png",
        "path": "paper_airplane_frames/paper_airplane_025.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_025.png.import",
        "path": "paper_airplane_frames/paper_airplane_025.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_026.png",
        "path": "paper_airplane_frames/paper_airplane_026.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_026.png.import",
        "path": "paper_airplane_frames/paper_airplane_026.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_027.png",
        "path": "paper_airplane_frames/paper_airplane_027.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_027.png.import",
        "path": "paper_airplane_frames/paper_airplane_027.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_028.png",
        "path": "paper_airplane_frames/paper_airplane_028.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_028.png.import",
        "path": "paper_airplane_frames/paper_airplane_028.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_029.png",
        "path": "paper_airplane_frames/paper_airplane_029.png",
        "size": 96,
        "modified": "2025-09-01T03:52:56.935Z"
      },
      {
        "type": "file",
        "name": "paper_airplane_029.png.import",
        "path": "paper_airplane_frames/paper_airplane_029.png.import",
        "size": 810,
        "modified": "2025-09-01T03:52:56.935Z"
      }
    ]
  },
  {
    "type": "file",
    "name": "auto_generate.gd",
    "path": "auto_generate.gd",
    "size": 197,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "auto_generate.tscn",
    "path": "auto_generate.tscn",
    "size": 180,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "batch_optimize_images.py",
    "path": "batch_optimize_images.py",
    "size": 8856,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "export_presets.cfg",
    "path": "export_presets.cfg",
    "size": 2416,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "generate_textures.tscn",
    "path": "generate_textures.tscn",
    "size": 198,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "icon.svg",
    "path": "icon.svg",
    "size": 923,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "icon.svg.import",
    "path": "icon.svg.import",
    "size": 842,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "IMAGE_OPTIMIZATION_GUIDE.md",
    "path": "IMAGE_OPTIMIZATION_GUIDE.md",
    "size": 854,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "IMAGE_OPTIMIZATION_USAGE.md",
    "path": "IMAGE_OPTIMIZATION_USAGE.md",
    "size": 2120,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "image_optimizer.gd",
    "path": "image_optimizer.gd",
    "size": 3867,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "image_optimizer.tscn",
    "path": "image_optimizer.tscn",
    "size": 212,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "main.gd",
    "path": "main.gd",
    "size": 16262,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "main.tscn",
    "path": "main.tscn",
    "size": 871,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "mouse_handler.gd",
    "path": "mouse_handler.gd",
    "size": 4379,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "optimize_images.py",
    "path": "optimize_images.py",
    "size": 3476,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "package.json",
    "path": "package.json",
    "size": 1877,
    "modified": "2025-09-01T03:52:56.936Z"
  },
  {
    "type": "file",
    "name": "paper_airplane_animation.py",
    "path": "paper_airplane_animation.py",
    "size": 8864,
    "modified": "2025-09-01T03:52:56.934Z"
  },
  {
    "type": "file",
    "name": "particle_manager.gd",
    "path": "particle_manager.gd",
    "size": 11680,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "project.godot",
    "path": "project.godot",
    "size": 1233,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "QUICKSTART.md",
    "path": "QUICKSTART.md",
    "size": 964,
    "modified": "2025-09-01T03:52:56.958Z"
  },
  {
    "type": "file",
    "name": "README_UPDATED.md",
    "path": "README_UPDATED.md",
    "size": 6961,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "README.md",
    "path": "README.md",
    "size": 4196,
    "modified": "2025-09-01T03:52:56.933Z"
  },
  {
    "type": "file",
    "name": "settings_manager.gd",
    "path": "settings_manager.gd",
    "size": 7569,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "settings_panel.gd",
    "path": "settings_panel.gd",
    "size": 11362,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "settings_panel.tscn",
    "path": "settings_panel.tscn",
    "size": 13371,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "sound_manager.gd",
    "path": "sound_manager.gd",
    "size": 9856,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "stress_ball.tscn",
    "path": "stress_ball.tscn",
    "size": 704,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "texture_generator.gd",
    "path": "texture_generator.gd",
    "size": 5886,
    "modified": "2025-09-01T03:52:56.935Z"
  },
  {
    "type": "file",
    "name": "toy.gd",
    "path": "toy.gd",
    "size": 3858,
    "modified": "2025-09-01T03:52:56.936Z"
  },
  {
    "type": "file",
    "name": "tutorial_manager.gd",
    "path": "tutorial_manager.gd",
    "size": 12074,
    "modified": "2025-09-01T03:52:56.936Z"
  },
  {
    "type": "file",
    "name": "VERSION.md",
    "path": "VERSION.md",
    "size": 872,
    "modified": "2025-09-01T03:52:56.958Z"
  }
]
```

## 文件说明

### 核心脚本
- **main.gd** - 主游戏逻辑，整合所有管理器
- **toy.gd** - 玩具基类，处理玩具物理和形变
- **mouse_handler.gd** - 鼠标交互处理

### 管理器系统
- **settings_manager.gd** - 设置和配置管理
- **sound_manager.gd** - 程序化音效系统
- **particle_manager.gd** - 粒子效果管理
- **tutorial_manager.gd** - 教程和帮助系统

### 用户界面
- **settings_panel.tscn** - 设置面板场景
- **settings_panel.gd** - 设置面板逻辑
- **main.tscn** - 主游戏场景

### 资源文件
- **assets/** - 纹理和图片资源
- **paper_airplane_frames/** - 纸飞机动画帧

### 文档
- **README.md** - 详细项目说明
- **SETUP.md** - 设置和安装指南
- **QUICKSTART.md** - 快速开始指南
- **VERSION.md** - 版本信息
- **package.json** - 包信息

### 配置文件
- **project.godot** - Godot 项目配置
- **export_presets.cfg** - 导出预设

---

*总计: 97 个文件*